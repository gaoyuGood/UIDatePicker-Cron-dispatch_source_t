//
//  HYCronTimerUtils.m
//  UniversalApp
//
//  Created by frank 高宇 on 18/5/20.
//  Copyright © 2018年 cmchy. All rights reserved.
//

#import "HYCronTimerUtils.h"

@implementation HYCronTimerUtils

#pragma mark - util
//http://www.jianshu.com/p/f03b1497122a
//生成cron表达式
+(NSString*)cronStringWithtime:(long long)time
                          week:(NSInteger)week
                       weekday:(NSInteger)weekday
{
    NSString* cron;
    
    long hour = time / 3600;
    long min = time / 60 % 60;
    long second = time % 60;
    
    //执行一次 应该设置 日月年, tbd.
    
    NSString* weekDesp=@"";
    if(week == 0){ //once
        weekDesp = @"?";
        NSDate* date = [NSDate date];
        NSCalendar * calendar = [NSCalendar currentCalendar]; // 指定日历的算法
        NSDateComponents *comps = [calendar components:kCFCalendarUnitSecond|NSCalendarUnitMinute|NSCalendarUnitHour|NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear fromDate:date];
        long long currentTime=comps.hour*60*60+comps.minute*60+comps.second;
        if (currentTime>=time) {
            NSDate *tomorrowDate = [NSDate dateWithTimeIntervalSinceNow:(24*60*60)];
            comps=[calendar components:kCFCalendarUnitSecond|NSCalendarUnitMinute|NSCalendarUnitHour|NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear fromDate:tomorrowDate];
        }
        cron = [NSString stringWithFormat:@"%ld %ld %ld %ld %ld %@ %ld",second,min,hour,comps.day,comps.month,weekDesp,comps.year];
        return cron;
    }else if(week == 127){ //every day
        weekDesp = @"*";
    }else{
        NSMutableString *weekString = [NSMutableString new];
        NSInteger weekIndex = 0;
        while (week) {
            if (week & 0x1) {
                if (0 != weekString.length) {
                    [weekString appendString:@","];
                }
                [weekString appendFormat:@"%ld", weekIndex+1]; //cron from 1-7
            }
            week >>= 1;
            ++weekIndex;
        }
        weekDesp = weekString;
    }
    
    //Seconds Minutes Hours Day-of-Month Month Day-of-Week Year
    cron = [NSString stringWithFormat:@"%ld %ld %ld ? * %@ *",second,min,hour,weekDesp];   //cron = @"0 0 8 ? * 2,3,4,5,6 *";
    
    return cron;
}

//不带秒的计时(定时)
+(NSString*)displayStringWithcronString:(NSString*)cronString;
{
    NSArray* arr = [cronString componentsSeparatedByString:@" "];
    if(arr.count < 6){
        return cronString;
    }
    
    NSString* min = arr[1];
    min = (min.length==1) ? [NSString stringWithFormat:@"0%@",min]:min;
    NSString* hour = arr[2];
    hour = (hour.length==1) ? [NSString stringWithFormat:@"0%@",hour]:hour;
    NSString* weekDesp = arr[5];
    NSString* dayOfWeek = [HYCronTimerUtils weekToDescription:weekDesp];
    
    NSString* disp = [NSString stringWithFormat:@"%@:%@ %@",hour,min,dayOfWeek];
    
    return disp;
}

//带秒的计时(倒计时)
+(NSString*)displaySecondStringWithcronString:(NSString*)cronString;
{
    NSArray* arr = [cronString componentsSeparatedByString:@" "];
    if(arr.count < 6){
        return cronString;
    }
    
    NSString* second = arr[0];
    second = (second.length==1) ? [NSString stringWithFormat:@"0%@",second]:second;
    NSString* min = arr[1];
    min = (min.length==1) ? [NSString stringWithFormat:@"0%@",min]:min;
    NSString* hour = arr[2];
    hour = (hour.length==1) ? [NSString stringWithFormat:@"0%@",hour]:hour;
    
    NSString* disp = [NSString stringWithFormat:@"%@:%@:%@",hour,min,second];
    
    return disp;
}

//触发时间
+ (NSString *)weekToDescription:(NSString*)weekDesp
{
    NSInteger week=0;
    
    if([weekDesp isEqualToString:@"*"]){
        return @"每天";
    }else if([weekDesp isEqualToString:@","] || [weekDesp isEqualToString:@"?"]){
        week = 0;
    }else
    {
        NSArray* weekarr = [weekDesp componentsSeparatedByString:@","];
        if(weekarr.count){
            for(NSString* wday in weekarr){
                long day = [wday longLongValue]-1;
                week |= 1<<day;
            }
        }else{
            NSArray* despArray = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7"];
            if([despArray containsObject:weekDesp] ){
                long day = [weekDesp longLongValue]-1;
                week |= 1<<day;
            }else{
                week = 0;
            }
        }
    }
    
    switch (week) {
        case 0:return @"";   //今天或者明天的单次触发不显示
        case 62:return @"工作日";
        case 65:return @"双休日";
        case 127:return @"每天";
        default:break;
    }
    
    NSMutableString *weekString = [NSMutableString new];
    NSString* headEvevyWeek = @"每周";
    [weekString appendFormat:@"%@",headEvevyWeek];
    NSInteger weekIndex = 0;
    while (week) {
        if(weekIndex >=8){
            break; //防止服务器传过来非法数据的异常情况
        }
        if ((week & 0x1 )) {
            if (weekString.length>=headEvevyWeek.length+1) {
                [weekString appendString:@", "];
            }
            
            {
                [weekString appendFormat:@"%@", [self numberToWeek:weekIndex]];
            }
        }
        week >>= 1;
        ++weekIndex;
    }
    return weekString;
}

+ (NSString *)numberToWeek:(NSInteger)num
{
    switch (num) {
        case 0:return @"日";
        case 1:return @"一";
        case 2:return @"二";
        case 3:return @"三";
        case 4:return @"四";
        case 5:return @"五";
        case 6:return @"六";
            
        default:return @"";
    }
}

@end
