//
//  HYCronTimerUtils.h
//  UniversalApp
//
//  Created by frank 高宇 on 18/5/20.
//  Copyright © 2018年 cmchy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HYCronTimerUtils : NSObject

//得到cron表达式
+(NSString*)cronStringWithtime:(long long)time
                          week:(NSInteger)week
                          weekday:(NSInteger)weekday;

//不带秒的计时 如(12:30 每天)
+(NSString*)displayStringWithcronString:(NSString*)cronString;

//带秒的计时 如(12:30:23 每天)
+(NSString*)displaySecondStringWithcronString:(NSString*)cronString;

@end
