//
//  ViewController.m
//  UIDatePicker+CronTimer
//
//  Created by 高宇 on 2019/2/28.
//  Copyright © 2019 高宇. All rights reserved.
//

#import "ViewController.h"
#import "HYCronTimerUtils.h"

@interface ViewController ()<UIPickerViewDelegate>
@property (nonatomic, strong) UIDatePicker *datePicker;
@property (nonatomic, strong) UILabel *timerLabel;
@property (nonatomic, strong) UIButton *beginBtn;
@property (nonatomic, strong) UIButton *stopBtn;
@property (nonatomic, strong) dispatch_source_t timer;    //GCD定时器
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configPickerView];   //创建时间选择控件
    
    [self configView];  //创建开始按钮
}

- (void)configView{
    [self.view addSubview:self.beginBtn];
    _beginBtn.frame = CGRectMake(50, 400, self.view.frame.size.width-100, 40);
    
    [self.view addSubview:self.timerLabel];
    _timerLabel.frame = CGRectMake(50, 500, self.view.frame.size.width-100, 40);
    
    
    [self.view addSubview:self.stopBtn];
    _stopBtn.frame = CGRectMake(50, 600, self.view.frame.size.width-100, 40);
}

- (void)configPickerView{
    UIDatePicker *datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 200)];
    
    //设置地区: zh-中国
    datePicker.locale = [NSLocale localeWithLocaleIdentifier:@"zh"];
    
    //设置日期模式(Displays month, day, and year depending on the locale setting)
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    
    //设置当前显示时间
    //需要转换的字符串
    NSString *dateString = @"5";   //格式2018-11-22 08:08:08对应yyyy-MM-dd HH:mm:ss   初始化为5
    //设置转换格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    [formatter setDateFormat:@"mm"];  //对应设置的5为分钟
    //NSString转NSDate
    NSDate *date=[formatter dateFromString:dateString];
    
    [datePicker setDate:date animated:YES];
    
    //监听DataPicker的滚动
    [datePicker addTarget:self action:@selector(dateChange:) forControlEvents:UIControlEventValueChanged];
    
    self.datePicker = datePicker;
    
    [self.view addSubview:self.datePicker];
}

//监听DataPicker滑动回调
- (void)dateChange:(UIDatePicker *)datePicker
{
    //date转化为long long格式
    NSDate *date = datePicker.date;
    NSCalendar * calendar = [NSCalendar currentCalendar]; // 指定日历的算法
    NSDateComponents *comps = [calendar components:NSCalendarUnitMinute|NSCalendarUnitHour|NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear fromDate:date];
    //取出小时和分钟
    NSInteger hour = comps.hour;
    NSInteger minite = comps.minute;
    
    NSLog(@"倒计时:%ld小时%ld分钟",hour,minite);
}

#pragma mark btnClick
-(void)beginBtnClick:(UIButton *)btn{
    
    //得到倒计时时间, date转化为long long格式
    NSDate *date = _datePicker.date;
    NSCalendar * calendar = [NSCalendar currentCalendar]; // 指定日历的算法
    NSDateComponents *comps = [calendar components:kCFCalendarUnitSecond|NSCalendarUnitMinute|NSCalendarUnitHour|NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear fromDate:date];
    NSInteger hour = comps.hour;
    NSInteger minite = comps.minute;
    long long selectedTime = hour*3600+minite*60;
    
    //得到当前时间
    NSDate* nowDate = [NSDate date];
    NSTimeZone* zone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSTimeInterval time = [zone secondsFromGMTForDate:nowDate];// 以秒为单位返回当前时间与系统格林尼治时间的差
    long long newTime = ([nowDate timeIntervalSince1970]+time);
    NSInteger nowhour = newTime / 3600;
    NSInteger nowminite = newTime / 60 % 60;
    NSInteger nowsecond = newTime % 60;
    nowhour %= 24;
    newTime = 3600*nowhour+60*nowminite+nowsecond;
    
    //定时触发时间为倒计时时间+当前时间
    long long countdownTime = selectedTime + newTime;
    
    //将触发时间转为cron表达式 (一般需要将该数据传给服务器,根据实际需求和后台给的时间格式来做处理)
    NSString* scheduleValue = [HYCronTimerUtils cronStringWithtime:countdownTime week:0 weekday:0];
    
    NSLog(@"该定时将在%@触发",scheduleValue);   //注意表达式的时间顺序:秒 分 小时 日 月 循环 年   解析时注意顺序
    
    [self createGCDTimer:scheduleValue];  //开启定时功能
}

#pragma mark 开启定时器
- (void)createGCDTimer:(NSString *)schedule{
    NSString* desc = [HYCronTimerUtils displaySecondStringWithcronString:schedule]; //得到12:27
    NSArray *tempArr = [desc componentsSeparatedByString:@":"];  //得到12 和 27
    NSString* hour = tempArr[0];
    NSString* min = tempArr[1];
    NSString* second = tempArr[2];
    int mins = [hour intValue]*3600+[min intValue]*60+[second intValue];
    
    //得到当前时间
    NSDate* nowDate = [NSDate date];
    NSTimeZone* zone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSTimeInterval time = [zone secondsFromGMTForDate:nowDate];// 以秒为单位返回当前时间与系统格林尼治时间的差
    int newTime = ([nowDate timeIntervalSince1970]+time);
    int nowhour = newTime / 3600;
    int nowminite = newTime / 60 % 60;
    int newsecond = newTime % 60;
    nowhour %= 24;
    newTime = 3600*nowhour+60*nowminite+newsecond;
    
    __block int timeout = mins-newTime; //得到倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(self.timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(self.timer, ^{
        if(timeout <= 0){ //倒计时结束，关闭
            dispatch_source_cancel(self.timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                NSLog(@"倒计时结束");
            });
        }else{
            int hour = timeout / 3600;
            int minute = timeout / 60 % 60;
            int second = timeout % 60;
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                self.timerLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",hour,minute,second];
            });
            timeout -= 1;
        }
    });
    dispatch_resume(self.timer);
}

-(void)stopBtnClick:(UIButton *)btn{
    dispatch_source_cancel(_timer);  //关闭定时器
}

#pragma mark get方法
- (UILabel *)timerLabel{
    if (!_timerLabel) {
        _timerLabel = [[UILabel alloc] init];
        _timerLabel.font = [UIFont systemFontOfSize:50];
        _timerLabel.textAlignment = 1;
        _timerLabel.textColor = [UIColor blackColor];;
    }
    return _timerLabel;
}

- (UIButton *)beginBtn {
    if (!_beginBtn) {
        _beginBtn = [[UIButton alloc]init];
        [_beginBtn setTitle:@"开始倒计时" forState:UIControlStateNormal];
        [_beginBtn addTarget:self action:@selector(beginBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _beginBtn.layer.cornerRadius = 20.f;
        _beginBtn.layer.masksToBounds = YES;
        _beginBtn.backgroundColor = [UIColor redColor];
    }
    return _beginBtn;
}

- (UIButton *)stopBtn {
    if (!_stopBtn) {
        _stopBtn = [[UIButton alloc]init];
        [_stopBtn setTitle:@"停止" forState:UIControlStateNormal];
        [_stopBtn addTarget:self action:@selector(stopBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _stopBtn.layer.cornerRadius = 20.f;
        _stopBtn.layer.masksToBounds = YES;
        _stopBtn.backgroundColor = [UIColor redColor];
    }
    return _stopBtn;
}

#pragma mark 生命周期
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    dispatch_source_cancel(_timer);   //注意在合适的地方释放定时器
}

- (void)dealloc
{
    NSLog(@"释放了我就放心了!!!");
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
